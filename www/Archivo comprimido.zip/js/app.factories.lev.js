﻿angular.module('app.factories.lev', [])
// -----------------------------------
.factory('LevFactory', function () { // carga valores por default de la vista 

    var defaultValuesLev = function (lev) {
        console.info('defaultValuesLev');
        var dataJson = {};
        switch (lev.type) {
            case 'infra_simple':
                dataJson.firtsName = '';
                dataJson.lastName = 'hola';
                dataJson.image = { test: 'hola' };
                dataJson.list_image = [{ test: 'hola' }];

                break;
            case 'infra_imueble': break;
            case 'infra_full': break;
            case 'tic_simple': break;
            case 'tic_admin': break;
            case 'sp': break;
        }

        return dataJson;
    };

    var validateValuesLev = function (lev, dataJson, menuRight) {

        switch (lev.type) {
            case 'infra_simple':
                var val_page_1 = (
                     dataJson.lastName != ''
                     && dataJson.firtsName != ''
                     );
                validateMenuRight(menuRight, '1', val_page_1, ! val_page_1 ? 'Revise Sección ( Campos Obligatorios )' : '');


            case 'infra_imueble': break;
            case 'infra_full': break;
            case 'tic_simple': break;
            case 'tic_admin': break;
            case 'sp': break;
        }
        
    };


    var validateMenuRight = function (menuRight , page , ready , msg) {
        for (var i = 0; i < menuRight.length; i++) {
            if (menuRight[i].page == page) {
                menuRight[i].ready = ready;
                menuRight[i].msg = msg;
            }
        }
    };

    return {
        default: function (lev) { return defaultValuesLev(lev) },
        validate: function (lev, dataJson, menuRight) { validateValuesLev(lev, dataJson, menuRight) },
    }
})
;