﻿angular.module('app.controllers.lev', ['ionic'])
.controller('LevInfraSimpleCtrl', function ($scope, $location) {
	console.info('LevInfraSimpleCtrl');
	// ------------------
	// --- inicializa el menu !! 
	// ------------------
	$scope.menuRight = [
      {
      	page: '1',
      	title: '1 Datos Generales',
      	ready: false,
      	msg: 'Pendiente',
      },
	  {
	  	page: '2_1',
	  	title: '2 Datos del Inmueble',
	  	ready: false,
	  	msg: 'Pendiente',
	  },
	];
	
	$scope.$emit('setMenu', $scope.menuRight);

})
//-------------------------------------
.controller('LevInfraInmueble', function ($scope, InmuebleFactory) {
	console.info('LevInfraInmueble');
})
//-------------------------------------
.controller('LevInfraFull', function ($scope, InmuebleFactory) {
	console.info('LevInfraFull');
})
//-------------------------------------
.controller('LevTicSimple', function ($scope, InmuebleFactory) {
	console.info('LevTicSimple');
})
//-------------------------------------
.controller('LevTicAdmin', function ($scope, InmuebleFactory) {
	console.info('LevTicAdmin');
})
//-------------------------------------
.controller('LevSP', function ($scope, InmuebleFactory) {
	console.info('LevSP');
})
//-------------------------------------

;